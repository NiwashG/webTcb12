﻿using Microsoft.AspNetCore.Mvc;

namespace webportal.Controllers
{
    public class TaxController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
