﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using webportal.Models;

namespace webportal.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitForm(ContactFormModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", model);
            }

            try
            {
                // Create mail message with hardcoded values to ensure it works
                var mailMessage = new MailMessage
                {
                    From = new MailAddress("sahilsahil38656@gmail.com", "The Capital Box"),
                    Subject = $"The Capital Box - New Contact Form Submission from {model.Name}",
                    Body = $@"<!DOCTYPE html>
<html>
<head>
    <meta charset=""utf-8"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
    <title>Contact Form Submission</title>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }}
        .header {{ background-color: #CBBA4F; padding: 20px; color: white; text-align: center; }}
        .content {{ padding: 20px; border: 1px solid #ddd; }}
        .footer {{ text-align: center; margin-top: 20px; font-size: 12px; color: #777; }}
        h1 {{ color: #333; }}
        .field {{ margin-bottom: 15px; }}
        .label {{ font-weight: bold; }}
    </style>
</head>
<body>
    <div class=""header"">
        <h1>The Capital Box - Contact Form</h1>
    </div>
    <div class=""content"">
        <p>A new contact form submission has been received from your website.</p>

        <div class=""field"">
            <div class=""label"">Name:</div>
            <div>{model.Name}</div>
        </div>

        <div class=""field"">
            <div class=""label"">Email:</div>
            <div><a href=""mailto:{model.Email}"">{model.Email}</a></div>
        </div>

        <div class=""field"">
            <div class=""label"">Subject:</div>
            <div>{(string.IsNullOrEmpty(model.Subject) ? "Not specified" : model.Subject)}</div>
        </div>

        <div class=""field"">
            <div class=""label"">Message:</div>
            <div>{model.Message.Replace("\n", "<br/>")}</div>
        </div>
    </div>
    <div class=""footer"">
        <p>This is an automated message from The Capital Box website contact form.</p>
        <p>&copy; {DateTime.Now.Year} The Capital Box. All rights reserved.</p>
    </div>
</body>
</html>",
                    IsBodyHtml = true
                };

                // Add recipient - use a hardcoded email address to ensure it's not null
                mailMessage.To.Add("sahilsahil38656@gmail.com"); // Send to this email

                // Add Reply-To header so replies go to the form submitter
                mailMessage.ReplyToList.Add(new MailAddress(model.Email, model.Name));

                // Add additional headers to improve deliverability
                mailMessage.Headers.Add("X-Priority", "1"); // High priority
                mailMessage.Headers.Add("X-MSMail-Priority", "High");
                mailMessage.Headers.Add("Importance", "High");
                mailMessage.Headers.Add("X-Auto-Response-Suppress", "OOF, DR, RN, NRN, AutoReply");

                // Configure SMTP client with hardcoded values
                using (var client = new SmtpClient("smtp.gmail.com", 587))
                {
                    // Ensure proper security settings
                    client.EnableSsl = true;
                    client.UseDefaultCredentials = false;
                    client.Credentials = new NetworkCredential("attapoll4747", "hnjr ylty vzbn xolh");
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.Timeout = 30000; // 30 seconds timeout

                    // Send email
                    await client.SendMailAsync(mailMessage);
                }

                // Add success message to TempData
                TempData["SuccessMessage"] = "Your message has been sent successfully. We'll get back to you soon!";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Log the exception
                ModelState.AddModelError(string.Empty, $"Failed to send message: {ex.Message}");
                return View("Index", model);
            }
        }
    }
}
