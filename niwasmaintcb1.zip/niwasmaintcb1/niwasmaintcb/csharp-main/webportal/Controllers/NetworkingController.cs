using Microsoft.AspNetCore.Mvc;

namespace webportal.Controllers
{
    public class NetworkingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
} 