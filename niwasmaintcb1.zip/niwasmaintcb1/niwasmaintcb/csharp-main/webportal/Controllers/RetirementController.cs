﻿using Microsoft.AspNetCore.Mvc;

namespace webportal.Controllers
{
    public class RetirementController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}



