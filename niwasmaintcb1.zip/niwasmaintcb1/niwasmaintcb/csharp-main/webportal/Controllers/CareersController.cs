﻿using Microsoft.AspNetCore.Mvc;

namespace webportal.Controllers
{
    public class CareersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
