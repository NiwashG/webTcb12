﻿namespace webportallibrary
{
    public class Class1
    {

    }
}
