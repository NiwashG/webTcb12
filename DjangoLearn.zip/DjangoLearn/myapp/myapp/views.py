from django.http import HttpResponse 
from django.shortcuts import render
import datetime
def home(request):
    if request.method == 'POST':
        check = request.POST.get('check', None)  # Use .get() to avoid errors if 'check' is missing
        if check:
            print(check)
    
    date=datetime.datetime.now()
  
     
    isActive=True
    # Name="Niwash  Kumar Singh"
    list_of_Programs=[
      
    ]
    student={
      

    }
    data={
      
    }
    return render(request,"home.html",data)
def about(request):
    # return HttpResponse("<h1>Helloe this is about page</h1>")
    return render(request,"about.html",{})

def Serveices(request):
   # return HttpResponse("<h1>Helloe this is servcices page</h1>")
   return render(request,"services.html",{})